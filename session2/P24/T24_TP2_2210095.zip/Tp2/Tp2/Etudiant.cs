﻿namespace Tp2
{
    public class Etudiant
    {
        public double TotalTp1, TotalTp2, TotalIntra, TotalFinal;
        public string? CodePermanent, Nom, Prenom, DateNaissance, Adresse, Ville, CodePostal, Telephone, NoId;
        public char Sexe;
        public double Tp1, Tp2, Intra, Final;
    }
}
   